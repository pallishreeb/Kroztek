module.exports = {
    PORT: 8000,
    deployment: "dev",
    MONGO_DB: 'mongodb+srv://croztek:Croztek@cluster0.ax5jgys.mongodb.net/kroztek?retryWrites=true&w=majority',
    EMAIL_FROM: 'shreelearning.tech@gmail.com',
    PASSWORD: 'psijctsbpfropysj'
};
