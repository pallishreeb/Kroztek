module.exports = {
    secretKey : "itsTooSecretMan"
}